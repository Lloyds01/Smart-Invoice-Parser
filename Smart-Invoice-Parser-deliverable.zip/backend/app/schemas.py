from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, model_validator


class ParseRequest(BaseModel):
    content: str | None = Field(default=None, description="Single invoice-like text")
    contents: list[str] | None = Field(default=None, description="Multiple texts")

    @model_validator(mode="after")
    def validate_one_of(cls, values: "ParseRequest") -> "ParseRequest":
        if (values.content is None and values.contents is None) or (
            values.content is not None and values.contents is not None
        ):
            raise ValueError("Provide either 'content' or 'contents'.")
        return values


class ParsedItem(BaseModel):
    product_name: str | None = None
    quantity: float | None = None
    unit: str | None = None
    price: float | None = None
    price_type: Literal["total", "unit"] | None = None
    derived_unit_price: float | None = None
    raw_line: str
    confidence: float


class ParseResult(BaseModel):
    input_index: int
    items: list[ParsedItem]


class ParseResponse(BaseModel):
    request_id: str
    results: list[ParseResult]


class HealthResponse(BaseModel):
    status: str = "ok"
