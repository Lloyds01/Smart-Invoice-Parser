# Project Guide (Detailed)

## Use case
This app extracts product-level data from noisy invoice-like text when invoices are pasted as unstructured text.
It is intended for workflows where strict document templates are unavailable.

## What the project does
- Splits input into candidate product lines.
- Ignores likely noise lines (invoice number, tax headers, address lines).
- Applies prioritized regex patterns.
- Returns optional fields when uncertain instead of forcing values.
- Computes confidence per item.
- Exposes parsing via FastAPI and a React UI with manual inline correction.

## Backend function map
- `backend/app/main.py`
  - `health()` -> liveness endpoint.
  - `stable_request_id()` -> deterministic hash for idempotent responses.
  - `parse_invoice()` -> accepts `content`/`contents`, validates max chars, parses, returns structured response.
- `backend/app/schemas.py`
  - Request and response Pydantic models.
- `backend/app/parser/regex_patterns.py`
  - Priority-ordered regex definitions.
  - Noise regex list.
- `backend/app/parser/postprocess.py`
  - Price cleaning, unit normalization, name normalization, confidence scoring.
- `backend/app/parser/extractor.py`
  - `split_candidate_lines()` -> line and delimiter-based splitting.
  - `is_noise_line()` -> line filtering.
  - `_extract_with_pattern()` -> pattern group to structured output.
  - `extract_from_line()` -> conflict resolution by confidence.
  - `extract_items()` -> end-to-end parse for one text blob.
- `backend/app/middleware/payload_limit.py`
  - Request payload byte limit and 413 responses.
- `backend/app/middleware/rate_limit.py`
  - In-memory per-IP fixed window limit and 429 responses.

## Frontend function map
- `frontend/src/api.js`
  - `parseInvoice()` -> HTTP client for `/parse`.
- `frontend/src/App.jsx`
  - Orchestrates parse flow, loading/error states, editable result state, retry, copy JSON.
- `frontend/src/components/PasteBox.jsx`
  - Text input + parse action.
- `frontend/src/components/ResultsTable.jsx`
  - Grouped display by `input_index`.
- `frontend/src/components/EditableRow.jsx`
  - Inline row editing of nullable fields.

## Test coverage
- Required sample formats.
- Noise filtering.
- Multi-item split with semicolons.
- Derived unit price for total-price patterns.

## Operational notes
- Local-first architecture.
- Swap in-memory state (rate limit) with Redis for distributed deployments.
- For very large invoices, use chunking and background queues.
