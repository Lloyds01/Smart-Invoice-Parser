export default function PasteBox({ value, onChange, onSubmit, loading }) {
  return (
    <section className="panel">
      <h2>Paste Invoice Text</h2>
      <textarea
        rows={10}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Paste invoice-like text here..."
      />
      <button onClick={onSubmit} disabled={loading || !value.trim()}>
        {loading ? 'Parsing...' : 'Parse'}
      </button>
    </section>
  )
}
