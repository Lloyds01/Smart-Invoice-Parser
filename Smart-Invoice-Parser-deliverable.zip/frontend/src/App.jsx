import { useMemo, useRef, useState } from 'react'
import { parseInvoice } from './api'
import PasteBox from './components/PasteBox'
import ResultsTable from './components/ResultsTable'

const sample = `Invoice # INV-1001
Sugar – Rs. 6,000 (50 kg)
Wheat Flour (10kg @ 950)
Cooking Oil: Qty 5 bottles Price 1200/bottle`

export default function App() {
  const [content, setContent] = useState(sample)
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const controllerRef = useRef(null)

  const canCopy = results.length > 0

  const copyPayload = useMemo(() => ({ results }), [results])

  async function runParse() {
    controllerRef.current?.abort()
    const controller = new AbortController()
    controllerRef.current = controller

    setLoading(true)
    setError('')

    try {
      const data = await parseInvoice(content, controller.signal)
      setResults(data.results || [])
    } catch (err) {
      setError(err.message || 'Failed to parse')
    } finally {
      setLoading(false)
    }
  }

  function handleRowChange(groupIndex, rowIndex, field, value) {
    setResults((prev) => {
      const next = structuredClone(prev)
      if (!next[groupIndex]?.items[rowIndex]) return prev

      if (value === '') {
        next[groupIndex].items[rowIndex][field] = null
      } else if (['quantity', 'price', 'derived_unit_price', 'confidence'].includes(field)) {
        const parsed = Number(value)
        next[groupIndex].items[rowIndex][field] = Number.isFinite(parsed) ? parsed : value
      } else {
        next[groupIndex].items[rowIndex][field] = value
      }

      return next
    })
  }

  async function copyJson() {
    await navigator.clipboard.writeText(JSON.stringify(copyPayload, null, 2))
  }

  return (
    <main className="container">
      <h1>Smart Invoice Parser</h1>

      {error && (
        <div className="error">
          <strong>Error:</strong> {error}
          <button onClick={runParse}>Retry</button>
        </div>
      )}

      <PasteBox value={content} onChange={setContent} onSubmit={runParse} loading={loading} />

      {loading && <div className="loading">Parsing in progress...</div>}

      <ResultsTable results={results} onRowChange={handleRowChange} />

      <button onClick={copyJson} disabled={!canCopy}>
        Copy JSON
      </button>
    </main>
  )
}
