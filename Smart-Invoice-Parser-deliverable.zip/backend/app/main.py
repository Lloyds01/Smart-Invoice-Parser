from __future__ import annotations

import hashlib
import json

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from app.middleware.payload_limit import PayloadLimitMiddleware
from app.middleware.rate_limit import FixedWindowRateLimitMiddleware
from app.parser import extract_items
from app.schemas import HealthResponse, ParseRequest, ParseResponse, ParseResult, ParsedItem

MAX_CHARS_PER_ITEM = 50_000

app = FastAPI(title="Smart Invoice Parser", version="1.0.0")

app.add_middleware(PayloadLimitMiddleware, max_bytes=200_000)
app.add_middleware(FixedWindowRateLimitMiddleware, requests_per_minute=120)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    return HealthResponse()


def stable_request_id(payload: dict) -> str:
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


@app.post("/parse", response_model=ParseResponse)
def parse_invoice(request: ParseRequest) -> ParseResponse:
    inputs = [request.content] if request.content is not None else request.contents or []

    for idx, text in enumerate(inputs):
        if len(text) > MAX_CHARS_PER_ITEM:
            raise HTTPException(
                status_code=413,
                detail=f"Input at index {idx} exceeds max character limit ({MAX_CHARS_PER_ITEM}).",
            )

    results: list[ParseResult] = []
    for i, text in enumerate(inputs):
        parsed = extract_items(text)
        results.append(
            ParseResult(
                input_index=i,
                items=[ParsedItem(**item.__dict__) for item in parsed],
            )
        )

    payload = {
        "content": request.content,
        "contents": request.contents,
        "results": [result.model_dump() for result in results],
    }
    request_id = stable_request_id(payload)
    return ParseResponse(request_id=request_id, results=results)
